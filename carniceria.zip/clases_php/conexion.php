

<?php

 $conexion = new mysqli("localhost" , "root" , "" ,"db_carniceria");



?>
