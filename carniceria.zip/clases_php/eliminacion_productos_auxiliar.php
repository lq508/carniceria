<?php

require_once("../pages/pagina_eliminacion.php");

 ?>
