<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex">

    <title></title>
  </head>
  <body>

    <h1> Error debe iniciar session </h1>
    <a href="../login.php"> iniciar session </a>

  </body>
</html>
